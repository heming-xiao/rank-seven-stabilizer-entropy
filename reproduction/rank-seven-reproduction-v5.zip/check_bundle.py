"""Check the release files and the audited Lean sources using the standard library."""

import hashlib
import json
from pathlib import Path
from zipfile import ZipFile


ROOT = Path(__file__).resolve().parent


def digest(data):
    return hashlib.sha256(data).hexdigest()


def require_digest(data, expected, name):
    if digest(data) != expected:
        raise SystemExit(f"SHA-256 mismatch: {name}")


def main():
    for line in (ROOT / "SHA256SUMS.txt").read_text(encoding="utf-8").splitlines():
        expected, name = line.split("  ", 1)
        require_digest((ROOT / name).read_bytes(), expected, name)

    record = json.loads((ROOT / "audit/independent-final-verification.json").read_bytes())
    archive = ROOT / "lean-v5.zip"
    require_digest(archive.read_bytes(), record["completeCandidateArchiveSHA256"], archive.name)
    log = ROOT / "audit/Rank7TheoremAudit.log"
    require_digest(log.read_bytes(), record["targetLogSHA256"], log.name)
    with ZipFile(archive) as sources:
        manifest = sources.read("source-manifest.json")
        require_digest(manifest, record["manifestSHA256"], "source-manifest.json")
        modules = json.loads(manifest)["modules"]
        expected_paths = {"src/" + name.replace(".", "/") + ".lean" for name in modules}
        actual_paths = [path for path in sources.namelist() if path.endswith(".lean")]
        if (set(actual_paths) != expected_paths or len(actual_paths) != len(expected_paths)
                or len(modules) != record["checkedModuleCount"]):
            raise SystemExit("Lean source inventory differs from the audit.")
        for name, entry in modules.items():
            path = "src/" + name.replace(".", "/") + ".lean"
            require_digest(sources.read(path), entry["source_sha256"], path)
    print(f"Release files, {len(modules):,} Lean sources, and the final audit log match.")


if __name__ == "__main__":
    main()
