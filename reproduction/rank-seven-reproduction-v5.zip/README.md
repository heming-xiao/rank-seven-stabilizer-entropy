# Exact nonlocal stabilizer Rényi entropy at Schmidt rank seven

Heming Xiao · Manuscript revised 21 November 2026

Zenodo version v3 contains the v5 Lean proof bundle and this manuscript.
[Version DOI](https://doi.org/10.5281/zenodo.24424358)

The PDF and its LaTeX source are in `paper/`. Given a normalized pure state in seven-term Schmidt form, the formalization proves that the sorted computational Schmidt representative attains the minimum over the full complex local-unitary orbit and gives the value of that minimum. The two qubit subsystems can have different dimensions.

## Reproduce the Lean proof

`lean-v5.zip` is the exact source archive used for the final audit. It includes 5,683 project modules, the source manifest, the Python build driver, the Lean toolchain file, and the Lake dependency lockfile. Use Python 3.11 or later and Lean 4.36.0 through elan. An internet connection is needed to fetch the pinned dependencies on a fresh machine. From the directory containing this README, run:

```sh
python check_bundle.py
python -m zipfile -e lean-v5.zip lean-v5
cd lean-v5
lake exe cache get
lake env python build_frozen_sources.py --jobs 2
```

Use a fresh extraction for a from-source run. To resume an interrupted build, run the last command again in the same directory. The driver checks per-module source, object, log, and import hashes before reusing its own checkpoints. Reduce `--jobs` to 1 if memory is limited. The final declaration report is written to `build/Rank7TheoremAudit.log`.

## Inspect the verification record

| Manuscript result | Lean declaration | Source in `lean-v5.zip` |
| --- | --- | --- |
| Theorem 1: the computational Schmidt representative attains the minimum | `RankSeven.FullSpectrumCertified.localUnitaryRepresentative` | `src/Rank7FullLocalUnitaryOrbit.lean` |
| Corollary 2: the minimum equals the explicit formula | `RankSeven.FullSpectrumCertified.localUnitaryMinimum` | `src/Rank7FullLocalUnitaryOrbit.lean` |
| Normalization and the minimum for a unit-norm input | `RankSeven.RealSchmidtOrbit.normalizedLocalUnitaryMinimum` | `src/Rank7CertifiedSchmidtOrbit.lean` |

The full review completed on 21 November 2026 using Lean 4.36.0 with warnings treated as errors. All 5,683 project modules compiled from source during this review. Of these, 4,208 compiled before the last source correction and had identical transitive source dependencies in v5. Another 1,475 compiled with the final source revision. The review used the pinned external Lean and Mathlib dependencies and checked 15,664 project import edges. This record supersedes the earlier build description inside the preserved source archive.

`audit/Rank7TheoremAudit.log` contains the Lean output for seven declarations. Six use only `propext`, `Classical.choice`, and `Quot.sound`. The plane enumeration uses only `propext`. The numerical coverage is proved within the formalization. `audit/independent-final-verification.json` records the declaration names, compiler and dependency versions, counts, and SHA-256 digests.

## Reproduce the external interval calculations

`external/rank-seven-reproduction-v1.zip` preserves the earlier C++ and Python proof supplement. Extract it separately and follow `literature/rank7_submission_proof_guide.md` inside it to replay the external interval calculations reported in Table 1. The Lean files and status notes inside that external supplement belong to the earlier release. Use `lean-v5.zip` for the full formal proof.

## Integrity and use

`SHA256SUMS.txt` lists the payload files and their SHA-256 digests. The Python check above also compares every Lean source file against the audited manifest and verifies the digest of the final axiom log. A successful integrity check establishes that these files match the recorded artifacts. Running the Lean build rechecks the proof itself.

The author permits downloading, citation, and local reproduction. Public redistribution or publication of adapted versions of the author's materials requires separate permission. Third-party dependencies retain their respective licenses.
